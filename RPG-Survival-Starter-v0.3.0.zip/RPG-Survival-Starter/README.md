# RPG Survival — Starter 0.1.0

Projeto inicial em português para um servidor **Paper Java com crossplay Bedrock via Geyser**.

> Importante: isto é uma base funcional inicial, não o RPG final de três anos. Inclui XP, níveis, classes iniciais, estatísticas e um objetivo introdutório. Os nomes das 16 raças e a seleção persistente já estão incluídos; bônus raciais, dungeons, chefes, economia, guildas, habilidades e campanhas ainda precisam ser implementados em versões posteriores.

## Compatibilidade

- O projeto compila contra Paper API 1.21.11 e Java 21.
- Paper é a plataforma do servidor Java.
- Geyser permite que clientes Bedrock entrem num servidor Java compatível; Floodgate pode facilitar autenticação Bedrock sem exigir conta Java paga.
- Em outubro de 2026, consulte a tabela oficial do Geyser antes de escolher a versão do servidor. As versões suportadas mudam; não atualize produção sem backup e teste.

Referências oficiais:
- Paper: https://docs.papermc.io/paper/getting-started/
- Geyser setup: https://geysermc.org/wiki/geyser/setup/
- Geyser versões suportadas: https://geysermc.org/wiki/geyser/supported-versions/
- Geyser downloads: https://geysermc.org/download
- Floodgate downloads: https://geysermc.org/download#floodgate

## O que funciona nesta versão

- `/rpg` e `/rpg help`: ajuda
- `/rpg stats`: nível, XP, classe, criaturas derrotadas e blocos minerados
- `/rpg class`: mostra a classe atual
- `/rpg class guerreiro|mago|arqueiro|curandeiro`: seleciona classe
- `/rpg race`: lista as 16 raças e mostra a atual
- `/rpg race <nome>`: escolhe uma raça
- `/rpg quest`: mostra o objetivo introdutório de derrotar 10 criaturas
- Ganho de XP ao derrotar criaturas e quebrar blocos
- Dados persistidos em `plugins/RPGSurvival/players.yml`
- Bônus inicial de dano do Guerreiro

## Compilar o plugin

É necessário um computador ou ambiente de build com **JDK 21** e **Maven 3.9+**.

1. Extraia o ZIP.
2. Abra um terminal na pasta `RPG-Survival-Starter`.
3. Execute `mvn clean package`.
4. O arquivo será criado em `target/RPG-Survival-0.1.0.jar`.

Se o servidor estiver numa versão mais nova que a API usada para compilar, teste primeiro num servidor de teste. Para uma produção na versão estável mais atual, atualize a dependência Paper API e a versão do Java conforme a documentação oficial da Paper.

## Instalar numa hospedagem

1. Faça backup do mundo e dos arquivos atuais.
2. No painel da hospedagem, selecione Paper como software. Evite Vanilla se pretende usar plugins.
3. Escolha uma versão suportada pelo Geyser e Java compatível com o Paper selecionado.
4. Compile o projeto e envie `target/RPG-Survival-0.1.0.jar` para a pasta `plugins/`.
5. Reinicie o servidor e verifique no console se `RPGSurvival` ativou.
6. Teste `/rpg`, `/rpg stats` e `/rpg quest`.
7. Instale Geyser-Spigot e Floodgate de fontes oficiais, na pasta `plugins/`, e reinicie.
8. No painel da hospedagem, reserve/habilite uma porta **UDP** para Bedrock. Configure essa porta em `plugins/Geyser-Spigot/config.yml`. Algumas hospedagens exigem usar uma porta alocada pelo painel ou clonar a porta Java; siga a instrução do provedor.
9. Teste primeiro com um jogador Java e depois com um jogador Bedrock.

**Não** coloque um arquivo `.jar` sem saber a origem. Baixe Geyser/Floodgate somente pelos links oficiais acima. Não desative `online-mode` por tentativa; escolha a autenticação de acordo com a configuração oficial do Floodgate e do seu provedor.

## Plano de produção

Antes de abrir para público:
- Fazer backup automático e testar restauração.
- Testar em servidor separado.
- Configurar permissões e moderação.
- Adicionar limites anti-farm e anti-exploit para XP.
- Validar itens, menus e mensagens em Java e Bedrock.
- Monitorar desempenho e logs.

## Roadmap de 36 meses (meta de conteúdo)

- Meses 1–3: base, 4 classes, onboarding, 30 missões.
- Meses 4–6: raças, profissões, crafting RPG, 2 dungeons.
- Meses 7–9: economia, lojas, NPCs, guildas iniciais.
- Meses 10–12: campanha do primeiro reino, chefes e equipamentos.
- Meses 13–18: continentes, especializações e raids.
- Meses 19–24: guerras de guildas, eventos e chefes mundiais.
- Meses 25–30: dimensões lendárias, relíquias e progressão avançada.
- Meses 31–36: campanha final, temporadas, balanceamento e conteúdo pós-jogo.

Esse roadmap é uma meta de desenvolvimento, não conteúdo já incluído neste starter.


## Versão 0.3.0 — chefes aleatórios

- O plugin tenta gerar um chefe a cada 15 minutos (configurável) quando há jogadores online.
- Tipos padrão: Ravager, Zombie e Skeleton.
- O chat anuncia mundo e coordenadas do chefe.
- `/rpg boss` mostra as coordenadas de um chefe ativo no mesmo mundo.
- Ao derrotar um chefe, há anúncio global e recompensa de XP configurável.
- Ajuste tudo na seção `bosses` de `plugins/RPGSurvival/config.yml`.

Compatibilidade: Paper com Java 21 e API Paper 1.21.11 conforme configurado no `pom.xml`. Confirme que a versão do seu servidor é compatível antes de instalar. Faça backup de `plugins/RPGSurvival/players.yml` e `config.yml` antes de substituir o JAR.
