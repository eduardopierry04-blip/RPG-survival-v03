# Roadmap de conteúdo (meta, não implementado)

## Ano 1 — O Despertar dos Reinos
- Fundamentos: persistência, XP, níveis, classes e estatísticas.
- Raças, habilidades e missões com objetivos e recompensas.
- NPCs, lojas, profissões e economia.
- Dungeons iniciais e campanha do primeiro reino.

## Ano 2 — A Guerra dos Antigos
- Continentes adicionais, especializações e progressão avançada.
- Raids, chefes mundiais e temporadas.
- Guildas, reputação e eventos cooperativos.

## Ano 3 — O Fim das Eras
- Dimensões especiais, relíquias e desafios de fim de jogo.
- Campanha final com múltiplos resultados.
- Conteúdo rotativo, conquistas, balanceamento e ferramentas de administração.

## Critérios de qualidade por atualização
- Teste em servidor separado.
- Backup antes da atualização.
- Teste Java + Bedrock.
- Teste de persistência após reiniciar.
- Teste de abuso de XP e desempenho.
