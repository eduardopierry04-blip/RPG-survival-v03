package br.rpgsurvival;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.EntityType;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.attribute.AttributeInstance;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;
import java.util.UUID;

public final class RPGSurvival extends JavaPlugin implements Listener {
    private org.bukkit.configuration.file.FileConfiguration players;
    private java.io.File playersFile;
    private org.bukkit.configuration.file.YamlConfiguration playerData;
    private NamespacedKey bossKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        playersFile = new java.io.File(getDataFolder(), "players.yml");
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        if (!playersFile.exists()) {
            try { playersFile.createNewFile(); }
            catch (java.io.IOException e) { getLogger().severe("Não foi possível criar players.yml: " + e.getMessage()); }
        }
        playerData = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(playersFile);
        getServer().getPluginManager().registerEvents(this, this);
        bossKey = new NamespacedKey(this, "rpg_boss");
        if (getConfig().getBoolean("bosses.enabled", true)) {
            long interval = Math.max(60, getConfig().getLong("bosses.interval-seconds", 900));
            getServer().getScheduler().runTaskTimer(this, this::trySpawnBoss, interval * 20L, interval * 20L);
            getLogger().info("Sistema de chefes aleatórios ativado; intervalo: " + interval + " segundos.");
        }
        getLogger().info("RPG Survival 0.3.0 ativado.");
    }

    @Override
    public void onDisable() { savePlayerData(); }

    private String key(Player p, String field) { return "players." + p.getUniqueId() + "." + field; }
    private int getInt(Player p, String field, int fallback) { return playerData.getInt(key(p, field), fallback); }
    private String getString(Player p, String field, String fallback) { return playerData.getString(key(p, field), fallback); }

    private void ensurePlayer(Player p) {
        String root = "players." + p.getUniqueId();
        if (!playerData.contains(root + ".name")) {
            playerData.set(root + ".name", p.getName());
            playerData.set(root + ".level", getConfig().getInt("starting-level", 1));
            playerData.set(root + ".xp", getConfig().getInt("starting-xp", 0));
            playerData.set(root + ".class", "adventurer");
            playerData.set(root + ".race", "human");
            playerData.set(root + ".mob-kills", 0);
            playerData.set(root + ".blocks-mined", 0);
            savePlayerData();
        } else {
            playerData.set(root + ".name", p.getName());
            if (!playerData.contains(root + ".race")) playerData.set(root + ".race", "human");
        }
    }

    private void savePlayerData() {
        if (playerData == null || playersFile == null) return;
        try { playerData.save(playersFile); }
        catch (java.io.IOException e) { getLogger().severe("Falha ao salvar players.yml: " + e.getMessage()); }
    }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    private void msg(CommandSender sender, String text) {
        sender.sendMessage(color(getConfig().getString("messages.prefix", "&6[RPG]&r ") + text));
    }

    private int xpNeeded(int level) {
        int base = getConfig().getInt("xp.xp-per-level-base", 100);
        int growth = getConfig().getInt("xp.xp-per-level-growth", 35);
        return base + Math.max(0, level - 1) * growth;
    }

    private void addXp(Player p, int amount, String reason) {
        if (amount <= 0) return;
        ensurePlayer(p);
        String xpPath = key(p, "xp");
        String levelPath = key(p, "level");
        int xp = playerData.getInt(xpPath) + amount;
        int level = playerData.getInt(levelPath, 1);
        msg(p, "&a+" + amount + " XP &7(" + reason + ")");
        while (xp >= xpNeeded(level)) {
            xp -= xpNeeded(level);
            level++;
            msg(p, "&e✦ NÍVEL AUMENTOU! &fVocê chegou ao nível &6" + level + "&f.");
            p.setLevel(Math.min( level, 100 ));
            p.setExp(0f);
            if (p.getAttribute(Attribute.MAX_HEALTH) != null) {
                double max = p.getAttribute(Attribute.MAX_HEALTH).getBaseValue();
                p.setHealth(Math.min(max, p.getHealth() + 2.0));
            }
        }
        playerData.set(xpPath, xp);
        playerData.set(levelPath, level);
        savePlayerData();
    }

    private void trySpawnBoss() {
        List<Player> online = new ArrayList<>(getServer().getOnlinePlayers());
        if (online.isEmpty()) return;
        List<String> types = getConfig().getStringList("bosses.entity-types");
        if (types.isEmpty()) types = List.of("RAVAGER", "ZOMBIE", "SKELETON");
        Player target = online.get(ThreadLocalRandom.current().nextInt(online.size()));
        World world = target.getWorld();
        int radius = Math.max(8, getConfig().getInt("bosses.spawn-radius", 30));
        Location spawn = null;
        for (int attempt = 0; attempt < 12; attempt++) {
            int dx = ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            int dz = ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            int x = target.getLocation().getBlockX() + dx;
            int z = target.getLocation().getBlockZ() + dz;
            if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
            Location candidate = world.getHighestBlockAt(x, z).getLocation().add(0.5, 1, 0.5);
            Material floor = candidate.clone().subtract(0, 1, 0).getBlock().getType();
            if (!candidate.getBlock().isPassable() || !candidate.clone().add(0, 1, 0).getBlock().isPassable()) continue;
            if (floor == Material.WATER || floor == Material.LAVA || floor == Material.MAGMA_BLOCK || floor == Material.CACTUS) continue;
            spawn = candidate;
            break;
        }
        if (spawn == null) {
            getLogger().info("Chefe aleatório ignorado: não foi encontrado local seguro perto de jogador.");
            return;
        }
        String chosen = types.get(ThreadLocalRandom.current().nextInt(types.size())).toUpperCase(Locale.ROOT);
        EntityType type;
        try { type = EntityType.valueOf(chosen); }
        catch (IllegalArgumentException ex) { type = EntityType.RAVAGER; }
        if (!type.isAlive() || !type.isSpawnable()) type = EntityType.RAVAGER;
        Entity entity = world.spawnEntity(spawn, type);
        if (!(entity instanceof LivingEntity boss)) {
            entity.remove();
            return;
        }
        double maxHealth = Math.max(20.0, getConfig().getDouble("bosses.max-health", 100.0));
        AttributeInstance healthAttribute = boss.getAttribute(Attribute.MAX_HEALTH);
        if (healthAttribute != null) {
            healthAttribute.setBaseValue(maxHealth);
            boss.setHealth(maxHealth);
        }
        boss.setCustomName(color(getConfig().getString("bosses.display-name", "&4Chefe Errante")));
        boss.setCustomNameVisible(true);
        boss.getPersistentDataContainer().set(bossKey, PersistentDataType.BYTE, (byte) 1);
        String coords = "X: " + spawn.getBlockX() + " Y: " + spawn.getBlockY() + " Z: " + spawn.getBlockZ();
        String announcement = color(getConfig().getString("bosses.spawn-message", "&c⚔ Um chefe apareceu em &f{world} &7({coords})!"))
                .replace("{world}", world.getName()).replace("{coords}", coords).replace("{boss}", ChatColor.stripColor(boss.getCustomName()));
        getServer().broadcastMessage(announcement);
        getLogger().info("Chefe criado: " + type + " em " + world.getName() + " " + coords);
    }

    @EventHandler
    public void onBossDeath(EntityDeathEvent e) {
        LivingEntity entity = e.getEntity();
        if (!entity.getPersistentDataContainer().has(bossKey, PersistentDataType.BYTE)) return;
        String coords = "X: " + entity.getLocation().getBlockX() + " Y: " + entity.getLocation().getBlockY() + " Z: " + entity.getLocation().getBlockZ();
        Player killer = entity.getKiller();
        String message = getConfig().getString("bosses.death-message", "&6{boss} foi derrotado em &f{world} &7({coords})!");
        message = message.replace("{boss}", ChatColor.stripColor(entity.getCustomName() == null ? "Chefe" : entity.getCustomName()))
                .replace("{world}", entity.getWorld().getName()).replace("{coords}", coords)
                .replace("{player}", killer == null ? "ninguém" : killer.getName());
        getServer().broadcastMessage(color(message));
        if (killer != null) addXp(killer, getConfig().getInt("bosses.reward-xp", 100), "chefe derrotado");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        ensurePlayer(e.getPlayer());
        e.getPlayer().sendMessage(color("&6Bem-vindo ao &eRPG Survival&6! Use &f/rpg &6para ver seus comandos."));
    }

    @EventHandler
    public void onMobKill(EntityDeathEvent e) {
        Player killer = e.getEntity().getKiller();
        if (killer == null || e.getEntity() instanceof Player) return;
        ensurePlayer(killer);
        int xp = getConfig().getInt("xp.mob-kill", 12);
        if (e.getEntity() instanceof Monster) xp += getConfig().getInt("xp.hostile-bonus", 8);
        addXp(killer, xp, "criatura derrotada");
        String path = key(killer, "mob-kills");
        playerData.set(path, playerData.getInt(path) + 1);
        savePlayerData();
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (e.getBlock().getType() == Material.AIR) return;
        ensurePlayer(p);
        addXp(p, getConfig().getInt("xp.block-break", 1), "exploração");
        String path = key(p, "blocks-mined");
        playerData.set(path, playerData.getInt(path) + 1);
        savePlayerData();
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        ensurePlayer(p);
        String chosen = getString(p, "class", "adventurer");
        int level = getInt(p, "level", 1);
        if (chosen.equals("warrior")) e.setDamage(e.getDamage() * (1.0 + Math.min(level, 50) * 0.002));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            msg(sender, "&eComandos: &f/rpg stats, /rpg class, /rpg race, /rpg quest, /rpg boss");
            msg(sender, "&7Ganhe XP derrotando criaturas e explorando. Mais sistemas chegarão nas próximas versões.");
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Este comando precisa ser usado dentro do jogo.");
            return true;
        }
        ensurePlayer(p);
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "boss", "chefe" -> {
                LivingEntity nearest = null;
                double best = Double.MAX_VALUE;
                for (World world : getServer().getWorlds()) {
                    for (Entity entity : world.getEntities()) {
                        if (!(entity instanceof LivingEntity living)) continue;
                        if (!living.getPersistentDataContainer().has(bossKey, PersistentDataType.BYTE)) continue;
                        if (!living.getWorld().equals(p.getWorld())) continue;
                        double distance = living.getLocation().distanceSquared(p.getLocation());
                        if (distance < best) { best = distance; nearest = living; }
                    }
                }
                if (nearest == null) msg(p, "&7Não há chefes ativos no seu mundo agora.");
                else msg(p, "&cChefe: &f" + ChatColor.stripColor(nearest.getCustomName()) + " &7| X: " + nearest.getLocation().getBlockX() + " Y: " + nearest.getLocation().getBlockY() + " Z: " + nearest.getLocation().getBlockZ());
            }
            case "stats", "status" -> {
                int level = getInt(p, "level", 1), xp = getInt(p, "xp", 0);
                msg(p, "&6Status de " + p.getName());
                msg(p, "&eNível: &f" + level + " &7| &eXP: &f" + xp + "/" + xpNeeded(level));
                msg(p, "&eClasse: &f" + getString(p, "class", "adventurer"));
                msg(p, "&eRaça: &f" + getString(p, "race", "human"));
                msg(p, "&eCriaturas derrotadas: &f" + getInt(p, "mob-kills", 0));
                msg(p, "&eBlocos minerados: &f" + getInt(p, "blocks-mined", 0));
            }
            case "class", "classe" -> {
                if (args.length == 1) {
                    msg(p, "&eClasse atual: &f" + getString(p, "class", "adventurer"));
                    msg(p, "&7Escolha: guerreiro, mago, arqueiro ou curandeiro.");
                    return true;
                }
                String c = args[1].toLowerCase(Locale.ROOT);
                String normalized = switch (c) {
                    case "guerreiro", "warrior" -> "warrior";
                    case "mago", "mage" -> "mage";
                    case "arqueiro", "archer" -> "archer";
                    case "curandeiro", "healer" -> "healer";
                    default -> null;
                };
                if (normalized == null) {
                    msg(p, "&cClasse inválida. Use guerreiro, mago, arqueiro ou curandeiro.");
                    return true;
                }
                playerData.set(key(p, "class"), normalized);
                savePlayerData();
                msg(p, "&aSua classe agora é: &e" + normalized + "&a. A progressão de classes será expandida em versões futuras.");
            }
            case "race", "raca", "raça" -> {
                if (args.length == 1) {
                    msg(p, "&eRaça atual: &f" + getString(p, "race", "human"));
                    msg(p, "&7Escolha uma das 16 raças:");
                    msg(p, "&fhumano, elfo, anao, orc, pequenino, gnomo, elfo_negro, draconiano");
                    msg(p, "&ftiefling, celestial, fera_sangue, povo_das_aguas, sangue_de_gigante, renascido, fada, golemita");
                    return true;
                }
                String c = args[1].toLowerCase(Locale.ROOT);
                String normalized = switch (c) {
                    case "humano", "human" -> "human";
                    case "elfo", "elf" -> "elf";
                    case "anao", "anão", "dwarf" -> "dwarf";
                    case "orc" -> "orc";
                    case "pequenino", "halfling" -> "halfling";
                    case "gnomo", "gnome" -> "gnome";
                    case "elfo_negro", "elfo-negro", "dark_elf" -> "dark_elf";
                    case "draconiano", "draconian" -> "draconian";
                    case "tiefling" -> "tiefling";
                    case "celestial" -> "celestial";
                    case "fera_sangue", "fera-sangue", "beastkin" -> "beastkin";
                    case "povo_das_aguas", "povo-das-águas", "merfolk" -> "merfolk";
                    case "sangue_de_gigante", "sangue-de-gigante", "giantkin" -> "giantkin";
                    case "renascido", "undead" -> "undead";
                    case "fada", "fairy" -> "fairy";
                    case "golemita", "golemkin" -> "golemkin";
                    default -> null;
                };
                if (normalized == null) {
                    msg(p, "&cRaça inválida. Use /rpg race para ver as opções.");
                    return true;
                }
                playerData.set(key(p, "race"), normalized);
                savePlayerData();
                String desc = getConfig().getString("races." + normalized + ".description", "Raça selecionada.");
                msg(p, "&aSua raça agora é &e" + getConfig().getString("races." + normalized + ".display-name", normalized) + "&a.");
                msg(p, "&7" + desc);
                msg(p, "&7Use /rpg boss para procurar chefes ativos no seu mundo.");
            }
            case "quest", "missao", "missão" -> {
                msg(p, "&eQuadro de aventureiro");
                msg(p, "&7Missão inicial: derrote 10 criaturas.");
                msg(p, "&7Progresso registrado: &f" + getInt(p, "mob-kills", 0) + "/10 criaturas.");
                if (getInt(p, "mob-kills", 0) >= 10) msg(p, "&aObjetivo concluído! Recompensa automática de XP já recebida pelas criaturas.");
            }
            default -> msg(p, "&cComando desconhecido. Use /rpg help.");
        }
        return true;
    }
}
